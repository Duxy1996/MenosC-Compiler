// Ejemplo de uso de asignaciones y operadores de incremento
{ int a; int b;

  read(a); print(a++); print(a);
  read(a); print(++a); print(a);

  read(a);
  b+=a; print(b); b-=a; print(b);
  b*=a; print(b); b/=a; print(b);
  print (a=b=7.2); print (a); print (b);
} 
