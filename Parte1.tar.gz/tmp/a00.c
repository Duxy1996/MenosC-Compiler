// Ejemplo sencillo del uso de operadores aritmeticos 
{ int a; int b; 

  read(a); 
  b = (((a + a) * 4) % 3) - ((3 * a) / 3);
  print(b);
}
